package bookManageProgram;

public class Program {
	public static void main(String[] args) {
		BookManager bm = new BookManager();
		bm.Load();
		bm.Run();
	}
}