package exHash;

//ISBN을 키로 도서 검색(HashMap 클래스 이용)
public class Program {
  public static void main(String[] args) {
    BookManager bm = new BookManager();
    bm.Run();
  }
}