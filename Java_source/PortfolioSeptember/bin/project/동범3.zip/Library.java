package project;

public interface Library {

}
